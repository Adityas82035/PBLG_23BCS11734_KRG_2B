package com.example.demo.model;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}
